#Booru Extractor

Firefox add-on for automatic extraction of images from image page of booru-like and other galleries. Files saved in a separate folders, for each gallery. 
Currently supported: Gelbooru, Danbooru, Safebooru, some of *.booru.org, e-hentai.org, Flickr.

1. Choose folder in options.
2. Open page with image.
3. Image automatically downloaded to folder, chosen in options. Gallery sub-folder will be created automatically.
